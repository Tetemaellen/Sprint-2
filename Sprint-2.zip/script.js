function redirecionarParaOutraPagina() {
    // Redireciona para a página "outra_pagina.html"
    window.location.href = "outra_pagina.html";
}
document.getElementById('meuBotao').addEventListener('click', function() {
    alert('Você clicou no botão!');
});
